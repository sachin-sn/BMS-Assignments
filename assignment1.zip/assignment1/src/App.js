import React from 'react';
import './App.css';

class App extends React.Component {
  constructor(props){
    super(props)
    this.state = {
      numArray: [
        1000,2000,3000,4000,5000,6000,7000,8000,9000,10000
      ],
      duplicateElements:[],
      uniqueElements:[]
    }
    this.onChange = this.onChange.bind(this)
  }
  
  onChange(num) {
    let userInput = num.split(',')
    console.log(userInput)
    let duplicates = this.state.duplicateElements.length>0 ? this.state.duplicateElements : [], unique = this.state.uniqueElements.length>0 ? this.state.uniqueElements: this.state.numArray
    userInput.forEach(element => {
      if(element.indexOf('-')>-1){
        let low = parseInt(element.split('-')[0].trim())
        let high = parseInt(element.split('-')[1].trim())
        console.log(low,high)
        let duplicateArr = unique.filter(num=>num>=low&&num<=high)
        duplicateArr.forEach(dup=>{
          unique = unique.filter(uel=>uel!==dup)
          duplicates.push(dup)
        })
        // for(let i=low;i<high;i++){
        //   if(duplicates.indexOf(i)===-1 && unique.indexOf(i)===-1){
        //     unique.push(i)
        //   }
        // }
      }else{
        let duplicate = unique.filter(num=>num===parseInt(element.trim()))[0]
        unique = unique.filter(uel=>uel!==duplicate)
        if(duplicate){
          duplicates.push(duplicate)
        }
        // if(this.state.uniqueElements.indexOf(element)===-1){
        //   unique.push(element)
        // }
      }
    });
    unique.sort((a,b)=>a-b)
    this.setState({
      ...this.state,
      duplicateElements: duplicates,
      uniqueElements: unique
    })
  }

  render(){
    let duplicateElements = this.state.duplicateElements.join(', ')
    let uniqueElements = this.state.uniqueElements.join(', ')
  return (
    <div className="App">
      <header className="App-header">
        <h3>Assignment #1</h3>
      </header>
      <div className="container">
        <div className="inputGroup">
          <label className="inputLabel">
            Enter numbers:&nbsp;
          </label>
          <input type = "text" className="textBox" placeholder="eg. 7000, 6000, 8000-8005" onChange={(e)=>this.onChange(e.target.value)}/>
        </div>
        <div className="resultGroup">
          <label>Duplicate Items:&nbsp;</label>{duplicateElements}<br/>
          <label>Unique Items:&nbsp;</label>{uniqueElements}
        </div>

      </div>
    </div>
  );}
}

export default App;
