import React from 'react';
import './App.css';

const httpGet = ()=>{
  return fetch('https://in.bookmyshow.com/serv/getData?cmd=GETTRAILERS&mtype=cs',(res,err)=>{
    if(err){Promise.reject()}
    if(res.statusCode==200){
      return res.Json();
    }
    return res.statusCode
  })
}

 class App extends React.Component {
  constructor (props){
    super(props)
    this.state = {
      isLoading:true,
      data: []

    }
  }
  componentWillMount(){
    httpGet().then((res)=>{
      this.setState({
        ...this.state,
        isLoading:false,
        data:res
      })
    })
  }
  render(){
    let isLoading = this.state.isLoading
    let data = this.state.data
    return (
    <div className="App">
      <header className="App-header">
        <h2>Movie Trailer</h2>
      </header>
      <div className="container">
        {
          isLoading ?
          <div>...isLoading....</div>
          :
          <div>data</div>
        }
      </div>
    </div>
  );}
}

export default App;
